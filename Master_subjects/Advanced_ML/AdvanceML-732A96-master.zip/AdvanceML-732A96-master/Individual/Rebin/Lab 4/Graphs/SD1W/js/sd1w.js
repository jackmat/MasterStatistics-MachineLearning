(function($) {
    $(document).ready(function() {
	
	$('#sd1w').scianimator({
	    'images': ['images/sd1w1.png', 'images/sd1w2.png', 'images/sd1w3.png', 'images/sd1w4.png', 'images/sd1w5.png', 'images/sd1w6.png', 'images/sd1w7.png', 'images/sd1w8.png', 'images/sd1w9.png', 'images/sd1w10.png', 'images/sd1w11.png', 'images/sd1w12.png', 'images/sd1w13.png', 'images/sd1w14.png', 'images/sd1w15.png', 'images/sd1w16.png', 'images/sd1w17.png', 'images/sd1w18.png', 'images/sd1w19.png', 'images/sd1w20.png', 'images/sd1w21.png', 'images/sd1w22.png', 'images/sd1w23.png', 'images/sd1w24.png', 'images/sd1w25.png', 'images/sd1w26.png', 'images/sd1w27.png', 'images/sd1w28.png', 'images/sd1w29.png', 'images/sd1w30.png', 'images/sd1w31.png', 'images/sd1w32.png', 'images/sd1w33.png', 'images/sd1w34.png', 'images/sd1w35.png', 'images/sd1w36.png', 'images/sd1w37.png', 'images/sd1w38.png', 'images/sd1w39.png', 'images/sd1w40.png', 'images/sd1w41.png', 'images/sd1w42.png', 'images/sd1w43.png', 'images/sd1w44.png', 'images/sd1w45.png', 'images/sd1w46.png', 'images/sd1w47.png', 'images/sd1w48.png', 'images/sd1w49.png', 'images/sd1w50.png', 'images/sd1w51.png', 'images/sd1w52.png', 'images/sd1w53.png', 'images/sd1w54.png', 'images/sd1w55.png', 'images/sd1w56.png', 'images/sd1w57.png', 'images/sd1w58.png', 'images/sd1w59.png', 'images/sd1w60.png', 'images/sd1w61.png', 'images/sd1w62.png', 'images/sd1w63.png', 'images/sd1w64.png', 'images/sd1w65.png', 'images/sd1w66.png', 'images/sd1w67.png', 'images/sd1w68.png', 'images/sd1w69.png', 'images/sd1w70.png', 'images/sd1w71.png', 'images/sd1w72.png', 'images/sd1w73.png', 'images/sd1w74.png', 'images/sd1w75.png', 'images/sd1w76.png', 'images/sd1w77.png', 'images/sd1w78.png', 'images/sd1w79.png', 'images/sd1w80.png', 'images/sd1w81.png', 'images/sd1w82.png', 'images/sd1w83.png', 'images/sd1w84.png', 'images/sd1w85.png', 'images/sd1w86.png', 'images/sd1w87.png', 'images/sd1w88.png', 'images/sd1w89.png', 'images/sd1w90.png', 'images/sd1w91.png', 'images/sd1w92.png', 'images/sd1w93.png', 'images/sd1w94.png', 'images/sd1w95.png', 'images/sd1w96.png', 'images/sd1w97.png', 'images/sd1w98.png', 'images/sd1w99.png', 'images/sd1w100.png'],
	    'width': 480,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#sd1w').scianimator('play');
    });
})(jQuery);
