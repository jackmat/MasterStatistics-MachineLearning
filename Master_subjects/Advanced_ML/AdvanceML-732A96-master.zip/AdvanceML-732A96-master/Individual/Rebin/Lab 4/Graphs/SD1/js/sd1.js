(function($) {
    $(document).ready(function() {
	
	$('#sd1').scianimator({
	    'images': ['images/sd11.png', 'images/sd12.png', 'images/sd13.png', 'images/sd14.png', 'images/sd15.png', 'images/sd16.png', 'images/sd17.png', 'images/sd18.png', 'images/sd19.png', 'images/sd110.png', 'images/sd111.png', 'images/sd112.png', 'images/sd113.png', 'images/sd114.png', 'images/sd115.png', 'images/sd116.png', 'images/sd117.png', 'images/sd118.png', 'images/sd119.png', 'images/sd120.png', 'images/sd121.png', 'images/sd122.png', 'images/sd123.png', 'images/sd124.png', 'images/sd125.png', 'images/sd126.png', 'images/sd127.png', 'images/sd128.png', 'images/sd129.png', 'images/sd130.png', 'images/sd131.png', 'images/sd132.png', 'images/sd133.png', 'images/sd134.png', 'images/sd135.png', 'images/sd136.png', 'images/sd137.png', 'images/sd138.png', 'images/sd139.png', 'images/sd140.png', 'images/sd141.png', 'images/sd142.png', 'images/sd143.png', 'images/sd144.png', 'images/sd145.png', 'images/sd146.png', 'images/sd147.png', 'images/sd148.png', 'images/sd149.png', 'images/sd150.png', 'images/sd151.png', 'images/sd152.png', 'images/sd153.png', 'images/sd154.png', 'images/sd155.png', 'images/sd156.png', 'images/sd157.png', 'images/sd158.png', 'images/sd159.png', 'images/sd160.png', 'images/sd161.png', 'images/sd162.png', 'images/sd163.png', 'images/sd164.png', 'images/sd165.png', 'images/sd166.png', 'images/sd167.png', 'images/sd168.png', 'images/sd169.png', 'images/sd170.png', 'images/sd171.png', 'images/sd172.png', 'images/sd173.png', 'images/sd174.png', 'images/sd175.png', 'images/sd176.png', 'images/sd177.png', 'images/sd178.png', 'images/sd179.png', 'images/sd180.png', 'images/sd181.png', 'images/sd182.png', 'images/sd183.png', 'images/sd184.png', 'images/sd185.png', 'images/sd186.png', 'images/sd187.png', 'images/sd188.png', 'images/sd189.png', 'images/sd190.png', 'images/sd191.png', 'images/sd192.png', 'images/sd193.png', 'images/sd194.png', 'images/sd195.png', 'images/sd196.png', 'images/sd197.png', 'images/sd198.png', 'images/sd199.png', 'images/sd1100.png'],
	    'width': 480,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#sd1').scianimator('play');
    });
})(jQuery);
