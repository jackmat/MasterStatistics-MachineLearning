(function($) {
    $(document).ready(function() {
	
	$('#sd5').scianimator({
	    'images': ['images/sd51.png', 'images/sd52.png', 'images/sd53.png', 'images/sd54.png', 'images/sd55.png', 'images/sd56.png', 'images/sd57.png', 'images/sd58.png', 'images/sd59.png', 'images/sd510.png', 'images/sd511.png', 'images/sd512.png', 'images/sd513.png', 'images/sd514.png', 'images/sd515.png', 'images/sd516.png', 'images/sd517.png', 'images/sd518.png', 'images/sd519.png', 'images/sd520.png', 'images/sd521.png', 'images/sd522.png', 'images/sd523.png', 'images/sd524.png', 'images/sd525.png', 'images/sd526.png', 'images/sd527.png', 'images/sd528.png', 'images/sd529.png', 'images/sd530.png', 'images/sd531.png', 'images/sd532.png', 'images/sd533.png', 'images/sd534.png', 'images/sd535.png', 'images/sd536.png', 'images/sd537.png', 'images/sd538.png', 'images/sd539.png', 'images/sd540.png', 'images/sd541.png', 'images/sd542.png', 'images/sd543.png', 'images/sd544.png', 'images/sd545.png', 'images/sd546.png', 'images/sd547.png', 'images/sd548.png', 'images/sd549.png', 'images/sd550.png', 'images/sd551.png', 'images/sd552.png', 'images/sd553.png', 'images/sd554.png', 'images/sd555.png', 'images/sd556.png', 'images/sd557.png', 'images/sd558.png', 'images/sd559.png', 'images/sd560.png', 'images/sd561.png', 'images/sd562.png', 'images/sd563.png', 'images/sd564.png', 'images/sd565.png', 'images/sd566.png', 'images/sd567.png', 'images/sd568.png', 'images/sd569.png', 'images/sd570.png', 'images/sd571.png', 'images/sd572.png', 'images/sd573.png', 'images/sd574.png', 'images/sd575.png', 'images/sd576.png', 'images/sd577.png', 'images/sd578.png', 'images/sd579.png', 'images/sd580.png', 'images/sd581.png', 'images/sd582.png', 'images/sd583.png', 'images/sd584.png', 'images/sd585.png', 'images/sd586.png', 'images/sd587.png', 'images/sd588.png', 'images/sd589.png', 'images/sd590.png', 'images/sd591.png', 'images/sd592.png', 'images/sd593.png', 'images/sd594.png', 'images/sd595.png', 'images/sd596.png', 'images/sd597.png', 'images/sd598.png', 'images/sd599.png', 'images/sd5100.png'],
	    'width': 480,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#sd5').scianimator('play');
    });
})(jQuery);
