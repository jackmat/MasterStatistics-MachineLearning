(function($) {
    $(document).ready(function() {
	
	$('#sd50').scianimator({
	    'images': ['images/sd501.png', 'images/sd502.png', 'images/sd503.png', 'images/sd504.png', 'images/sd505.png', 'images/sd506.png', 'images/sd507.png', 'images/sd508.png', 'images/sd509.png', 'images/sd5010.png', 'images/sd5011.png', 'images/sd5012.png', 'images/sd5013.png', 'images/sd5014.png', 'images/sd5015.png', 'images/sd5016.png', 'images/sd5017.png', 'images/sd5018.png', 'images/sd5019.png', 'images/sd5020.png', 'images/sd5021.png', 'images/sd5022.png', 'images/sd5023.png', 'images/sd5024.png', 'images/sd5025.png', 'images/sd5026.png', 'images/sd5027.png', 'images/sd5028.png', 'images/sd5029.png', 'images/sd5030.png', 'images/sd5031.png', 'images/sd5032.png', 'images/sd5033.png', 'images/sd5034.png', 'images/sd5035.png', 'images/sd5036.png', 'images/sd5037.png', 'images/sd5038.png', 'images/sd5039.png', 'images/sd5040.png', 'images/sd5041.png', 'images/sd5042.png', 'images/sd5043.png', 'images/sd5044.png', 'images/sd5045.png', 'images/sd5046.png', 'images/sd5047.png', 'images/sd5048.png', 'images/sd5049.png', 'images/sd5050.png', 'images/sd5051.png', 'images/sd5052.png', 'images/sd5053.png', 'images/sd5054.png', 'images/sd5055.png', 'images/sd5056.png', 'images/sd5057.png', 'images/sd5058.png', 'images/sd5059.png', 'images/sd5060.png', 'images/sd5061.png', 'images/sd5062.png', 'images/sd5063.png', 'images/sd5064.png', 'images/sd5065.png', 'images/sd5066.png', 'images/sd5067.png', 'images/sd5068.png', 'images/sd5069.png', 'images/sd5070.png', 'images/sd5071.png', 'images/sd5072.png', 'images/sd5073.png', 'images/sd5074.png', 'images/sd5075.png', 'images/sd5076.png', 'images/sd5077.png', 'images/sd5078.png', 'images/sd5079.png', 'images/sd5080.png', 'images/sd5081.png', 'images/sd5082.png', 'images/sd5083.png', 'images/sd5084.png', 'images/sd5085.png', 'images/sd5086.png', 'images/sd5087.png', 'images/sd5088.png', 'images/sd5089.png', 'images/sd5090.png', 'images/sd5091.png', 'images/sd5092.png', 'images/sd5093.png', 'images/sd5094.png', 'images/sd5095.png', 'images/sd5096.png', 'images/sd5097.png', 'images/sd5098.png', 'images/sd5099.png', 'images/sd50100.png'],
	    'width': 480,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#sd50').scianimator('play');
    });
})(jQuery);
