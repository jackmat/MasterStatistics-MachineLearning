function y = tanhprim(x)
y = 1 - tanh(x).^2;

